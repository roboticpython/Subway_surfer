from ursina import *

class Hoverboard(Entity):
    def __init__(self):
        super().__init__(
            model='cube',  # You should replace this with your hoverboard model
            color=color.red,
            scale=(1, 0.1, 2),
            collider='box',  # Adjust the collider shape as needed
        )
        self.speed = 5  # Adjust the hoverboard's speed
        self.hover_height = 0.5  # Adjust the hover height
        self.hover_speed = 2  # Adjust the hover speed

    def update(self):
        self.hover()

    def hover(self):
        hover_offset = sin(time.time * self.hover_speed) * self.hover_height
        self.y = hover_offset

class Game(Entity):
    def __init__(self):
        super().__init__()

        self.hoverboard = Hoverboard()

    def input(self, key):
        if key == 'space':
            self.hoverboard.speed = 10  # Increase speed when spacebar is pressed
        elif key == 'space up':
            self.hoverboard.speed = 5  # Reset speed when spacebar is released

app = Ursina()
game = Game()
app.run()
