from ursina import *
import random
from  pyautogui import *
app = Ursina()
# window.fullscreen = True
ground = Entity(model="cube", color=color.green, scale=(15, .5, 100), position=(0, 0))
camera.position = (0, 8, -50)
camera.rotation_x = 20
camera.rotation_y = 0
camera.rotation_z = 0
tracks = []
for i in range(3):
    for j in range(2):
        track = Entity(model="train_track.glb", scale=(1, 1, 2.5), position=(-5 + i * 5, 0.4, -5 + j * 25),color=color.white)
        tracks.append(track)
position = [-5, 5, 0]
train1 = Entity(model='trains.obj', texture='trains.png', scale=(0.2, 0.2, 0.2), position=(random.choice(position), 0.4, 20),collider = "box")
train = Entity(model='trains.obj', texture='trains.png', scale=(0.2, 0.2, 0.2), position=(random.choice(position), 0.4, 20),collider = "box")
train_speed = 45
tracks_speed1 = 20
player = FrameAnimation3d('run\\run_', scale=(1, 1, 1), fps=40, position=(0, 0, -35), texture="avatar_slick.png",collider = "box")
player.enabled = True
player_death = FrameAnimation3d('death\\untitled_', scale=(1, 1, 1) ,fps=50, position=(player.x, 0, -35), texture="avatar_slick.png",collider = "box")
player_jump = FrameAnimation3d('jump\\jump_', scale=(0.7 , 0.7, 0.7) ,fps=35, position=(player.x, 0, -35), texture="avatar_slick.png")
#player_roll = FrameAnimation3d('roll\\roll_', scale=(0.8, 0.8, 0.8) ,fps=40, position=(player.x, 0, -35), texture="avatar_slick.png")
player_jump.enabled = False
player_death.enabled = False
min_x = -5
max_x = 5
camera.add_script(SmoothFollow(target=player,offset=(0,7,-13)))
def update():
    global train_speed, tracks_speed1, player, train, train1
    train1.z -= time.dt * train_speed
    if train1.z < -50:
        train1.z = 20
        train1.x = random.choice(position)
    train.z -= time.dt * tracks_speed1
    if train.z < -50:
        train.z = 20
        train.x = random.choice(position)
    for track in tracks:
        track.z -= time.dt * tracks_speed1
        if track.z < -20:
            track.z = 20
    if held_keys['d']:
        player.x = min(player.x + 0.8, max_x)
    if held_keys['a']:
        player.x = max(player.x - 0.8, min_x)
    if held_keys['w']:
        player_jump.enabled = True
        player.enabled = False
        player_jump.x = player.x
    else:
        player_jump.enabled = False
        player.enabled = True
    if player.intersects().hit:
        player.enabled = False
        player_death.enabled = True
        tracks_speed1 = 0
        train_speed = 0
        player_death.x = player.x
        player_jump.enabled = False
        player_death.loop = False
    else:
        player_death.enabled = False
app.run() 