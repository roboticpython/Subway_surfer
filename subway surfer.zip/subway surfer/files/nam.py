import json

def load_leaderboard(filename):
    try:
        with open(filename, 'r') as file:
            leaderboard_data = json.load(file)
        return leaderboard_data
    except FileNotFoundError:
        return {}

def save_leaderboard(leaderboard_data, filename):
    with open(filename, 'w') as file:
        json.dump(leaderboard_data, file, indent=4)

def update_leaderboard(player_name, score, leaderboard_data):
    if player_name in leaderboard_data:
        leaderboard_data[player_name] += score
    else:
        leaderboard_data[player_name] = score

def display_leaderboard(leaderboard_data):
    print("Leaderboard:")
    sorted_leaderboard = sorted(leaderboard_data.items(), key=lambda x: x[1], reverse=True)
    for rank, (player, score) in enumerate(sorted_leaderboard, start=1):
        print(f"{rank}. {player}: {score}")

leaderboard_filename = "leaderboard.json"

leaderboard_data = load_leaderboard(leaderboard_filename)

while True:
    player_name = input("Enter player name (or 'q' to quit): ")
    if player_name.lower() == 'q':
        break

    try:
        score = int(input("Enter player score: "))
    except ValueError:
        print("Invalid score. Please enter a valid number.")
        continue

    update_leaderboard(player_name, score, leaderboard_data)
    save_leaderboard(leaderboard_data, leaderboard_filename)
    print(f"Score added for {player_name}.")

display_leaderboard(leaderboard_data)
